﻿# Source
https://github.com/Martin-Pitt/dsp-prod-ratios/tree/main/src/spritesheets